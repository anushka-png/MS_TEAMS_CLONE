//importing required libraries

const express = require('express');
var cookieSession = require("cookie-session");
const app = express();
let http = require('http').createServer(app);
let io = require('socket.io')(http);
var bodyParser = require('body-parser')
var path = require('path');


const pool = require('./pool');


app.set('view engine','ejs') ;

//static hosting using express.
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
 
// parse application/json
app.use(bodyParser.json())

app.use(express.static('public')) ;


app.use(
    cookieSession({
      name: "session",
      keys: ["naman"],
  
       //Cookie Options
      maxAge: 168 * 60 * 60 * 100 // 24 hours
    })
  );
  

app.get('/', (req,res)=>{
    if(req.session.username){
        res.render('index',{login:true,username:req.session.username}) ;

    }
    else {
        res.render('index',{login:false}) ;

    }
})

app.get('/signup',(req,res)=>{
    res.render('signup',{msg :''})
})


app.post('/login',(req,res)=>{
    let body = req.body;
    console.log('body',req.body)
    pool.query(`select * from user where email = '${req.body.email}' and password = '${req.body.password}'`,(err,result)=>{
        if(err)  throw err;
        else if(result[0]){
            req.session.username = result[0].name;
            res.redirect('/');
        }
        else {
            res.render('signup',{msg : 'Invalid Credentials'})
        }
    })
})



app.post('/insert',(req,res)=>{
let body = req.body
console.log('body123',req.body)
    pool.query(`select * from user where email = '${req.body.email}'`,(err,result)=>{
        if(err) throw err;
        else if(result[0]){
          res.json({
              msg : 'Email Alreagy Registered'
          })
        }
        else {
            pool.query(`insert into user set ?`,body,(err,result)=>{
                if(err) throw err;
                else {
                    req.session.username = req.body.name
                    res.json({
                        msg : 'success'
                    })
                }
            })
        }
    })

  
})



app.get('/logout',(req,res)=>{
    req.session.username = null;
    res.redirect('/')
})


//listener

http.listen(5500, function(){
    console.log('server running on http://localhost:5500') ;
});

// Signalling handlers

io.on('connection', function(socket){
    console.log('a user is connected');

    // When clients emits create or join

    socket.on('create or join', function (room){

        let myRoom = io.sockets.adapter.rooms.get(room);
        console.log(myRoom);
        let numClients = myRoom ? myRoom.size : 0;
        
        // console.log(room, 'has', numClients, 'clients');
        
        // These events are emitted only to the sender socket.

        if(numClients == 0){ // No users in the room
          console.log('creating room', room);  
          socket.join(room);
          socket.emit('created', room);
          
        }
        else if(numClients == 1){  // One user is already in the room
            console.log('joining room', room); 
            socket.join(room);
            socket.emit('joined', room);
        }
        else{  // Two participants are already in the room
            console.log('cannot create a room', room); 
            socket.emit('full', room);
        }
        console.log(room, 'has', numClients, 'clients');
    })

    // Relay only handlers

    // These events are emitted to all the sockets connected to the same room except the sender.
    
    socket.on('ready', function (room){
        socket.broadcast.to(room).emit('ready');
    });

    socket.on('candidate', function(event){
        socket.broadcast.to(event.room).emit('candidate', event);
    });

    socket.on('offer', function(event){
        socket.broadcast.to(event.room).emit('offer', event.sdp);
    });

    socket.on('answer', function(event){
        socket.broadcast.to(event.room).emit('answer', event.sdp);
    });
});
